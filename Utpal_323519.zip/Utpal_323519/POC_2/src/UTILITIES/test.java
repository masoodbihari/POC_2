package UTILITIES;

import java.util.ArrayList;

public class test {
	public static void main(String args[]) {
		ArrayList<Person> arr = new ArrayList<Person>(3);
		excel_operations.read_excel(arr);
		System.out.println(arr.get(2).email);
		System.out.println(arr.get(2).password);
		System.out.println(arr.get(2).expected);
	}
}
