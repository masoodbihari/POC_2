package UTILITIES;

import org.apache.log4j.Logger;

public class Person {
	Logger log;
	public String email;
	public String password;
	public String expected;
	void put_data(String storage_string[]) {
		this.email = storage_string[0];
		this.password = storage_string[1];
		this.expected = storage_string[2];
	}
}
