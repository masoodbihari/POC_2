package BASE_CLASSES;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class login_page extends home_page{
	@FindBy(xpath="//input[@id=\"email\"]")
	WebElement email_textfield;
	@FindBy(xpath="//input[@id=\"passwd\"]")
	WebElement password_textfield;
	@FindBy(xpath="//button[@id=\"SubmitLogin\"]")
	WebElement signin_button_2;
	public login_page(WebDriver dr){
		super(dr);
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
	void set_email(String email) {
		email_textfield.sendKeys(email);
	}
	void set_password(String password) {
		password_textfield.sendKeys(password);
	}
	public void click_signin_button() {
		signin_button_2.click();
	}
	public void perform_login(String email,String password) {
		//System.out.println(email + "--" + password);
		dr.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		set_email(email);
		set_password(password);
	}
	public String verify_login_page_title() {
		try {
			WebDriverWait wt = new WebDriverWait(dr,10);
			wt.until(ExpectedConditions.titleIs(dr.getTitle()));
			return dr.getTitle();
		}catch(Exception e) {
			System.out.println("Element not found in login page");
			return "xxxx";
		}
	}
}
