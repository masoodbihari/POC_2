package BASE_CLASSES;

import org.apache.log4j.Logger;

public class log_class {
	    public void writeLog(String name,String av,String ev) {
	        Logger log;
	        log=Logger.getLogger("devpinoyLogger");
	        log.info("====================================================================================");
	        log.info("----------------------------------"+name+"------------------------------------------");
	        log.info("====================================================================================");
	        
	        log.info("Expected Value : "+ev);
	        log.info("Actual Value : "+av);
	        
	        log.info("");
	        
	    }
}
